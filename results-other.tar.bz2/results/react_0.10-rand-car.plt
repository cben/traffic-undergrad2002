set terminal postscript color
set data style lines
set output 'react_0.10-rand-car.ps'
set title 'react_0.10-rand-car'
plot 'react_0.10-rand_5x5-car.dat', 'react_0.10-rand_15x15-car.dat', 'react_0.10-rand_10x10-car.dat'
